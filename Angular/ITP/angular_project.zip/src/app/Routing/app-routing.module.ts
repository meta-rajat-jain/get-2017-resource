import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from '../home/home.component';
import { AdminComponent } from '../admin/admin.component';
import { EmployeeDetailComponent } from '../employee-detail/employee-detail.component';





const routes: Routes = [
  { path: '', component:HomeComponent}
  ,
  { path: 'adminDashboard',  component: AdminComponent },
  { path: 'employeeDetail/:username/:type', component: EmployeeDetailComponent },
  
  /*{ path: 'productsList', component: ProductsComponent },
  { path: 'contactUs', component: ContactUsComponent },
  { path: 'addProduct', component: AddProductComponent },
  { path: 'getProductDetail/:id', component: GetProductDetailComponent },
  { path: 'cart', component: Cart },
  { path: 'checkout', component: Checkout },
  { path: 'payment', component: PaymentComponent },
  { path: 'order', component:OrderComponent},
  { path: 'orderDetail/:orderId', component:OrderDetailComponent}*/

];

@NgModule({
  imports: [ RouterModule.forRoot(routes) ],
  exports: [ RouterModule ]
})
export class AppRoutingModule {}

export class TicketStatusCount{
     status:string;
   count:number; 
}
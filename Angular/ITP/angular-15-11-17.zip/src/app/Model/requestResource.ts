export class RequestedResource{

resourceId:number;
resourceName:string;
resourceCategoryName:string;
}
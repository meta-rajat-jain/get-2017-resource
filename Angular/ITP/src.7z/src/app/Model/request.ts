export class RequestResource{
ticketNo:number;
requestedBy:string;
requestFor:string;
priority:string;
resourceRequested:string;
comment:string;
location:string;

}
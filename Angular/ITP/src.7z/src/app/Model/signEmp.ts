import { Login } from "./login";

export class Employee {
    name:string;
    contactNumber:number;
    orgDomain:string;
    designation:string;
    status:string;
    login:Login;

}
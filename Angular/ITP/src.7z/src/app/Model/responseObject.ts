import { Authentication } from "./Authentication";

export class ResponseObject {
    response:Authentication;
    employeeType:string;
}
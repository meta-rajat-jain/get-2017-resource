import { Login } from "./login";

export class signUpOrganisation {
    name:string;
    contactNumber:number;
    domain:string;
    login:Login;
}
export class AuthenticatedHeader{   
     username: string;
    authenticationToken:string;
}
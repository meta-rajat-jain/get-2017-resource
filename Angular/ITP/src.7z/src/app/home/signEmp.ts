import { Login } from "./login";

export class signUpEmployee {
    name:string;
    contactNumber:number;
    orgDomain:string;
    designation:string;
    status:string;
    login:Login;

}
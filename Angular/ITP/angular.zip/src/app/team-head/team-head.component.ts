import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-team-head',
  templateUrl: './team-head.component.html',
  styleUrls: ['./team-head.component.css']
})
export class TeamHeadComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

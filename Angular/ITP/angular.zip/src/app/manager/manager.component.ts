import { Component, OnInit } from '@angular/core';
import { AuthenticatedHeader } from '../Model/authenticatedHeader';
import { ManagerService } from './manager.service';
import { Authentication } from '../Model/Authentication';
import { Router } from '@angular/router';
import { AdminService } from '../admin/admin.service';
import { Employee } from '../Model/signEmp';

@Component({
  selector: 'app-manager',
  templateUrl: './manager.component.html',
  styleUrls: ['./manager.component.css']
})
export class ManagerComponent implements OnInit {
  username:string;
  authenticationHeader:AuthenticatedHeader;
  authentication:Authentication;
  employees:Employee[]=[];
  title:string;
  constructor(private managerService:ManagerService, private router:Router,private adminService:AdminService) { }

  ngOnInit() {
    this.authenticationHeader=JSON.parse(localStorage.getItem('authenticationObject'));
    console.log(this.authenticationHeader.username);
    let name = this.authenticationHeader.username.split('@');
    this.username = name[0];
  }

  createTeam(teamName:string,headName:string):void{
   
    this.managerService.createTeam(teamName,headName).then(response => {
    console.log("service response");
   
    });
   location.reload(true);
  }

  logOut(){
    this.managerService.logOutManager().then(response => {
      this.authentication = response;
      if (this.authentication.statusCode == 1){
        localStorage.clear();
        localStorage.removeItem('authenticationObject');
        this.router.navigate(['']);
      }
    });
  }
  checkEmployee(headName:string):void{
    this.adminService.getEmployees().then( response => {this.employees = response;
      
            for(let emp of this.employees){
              console.log("before if" + headName);
              console.log(emp.login.username);
              if(headName == emp.login.username){
                console.log(headName +"==" + emp.login.username);
                this.title='';
                break;
              }
              else{

                this.title='Invalid user';
              }
            }
          } )
  }

}

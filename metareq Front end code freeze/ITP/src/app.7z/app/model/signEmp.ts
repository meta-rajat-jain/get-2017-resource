import { Login } from "./login";

export class Employee {
    name:string;
    contactNumber:number;
    orgDomain:string;
    designation:any;
    status:string;
    login:Login;

}
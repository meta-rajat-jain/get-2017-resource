export class AuthenticatedHeader{   
     username: string;
     authorisationToken:string;
}
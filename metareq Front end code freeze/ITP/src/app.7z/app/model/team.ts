export class Team{
     teamName:string;
     orgDomain:string;
     teamHeadUsername:string;
}